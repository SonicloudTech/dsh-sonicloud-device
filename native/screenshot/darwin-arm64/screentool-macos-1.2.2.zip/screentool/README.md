# screentool 1.2.2 —— 截图/滚动长截图库（macOS arm64）

客户端库 + 独立 helper 进程架构：libscreentool 负责管道通信与会话管理，
screenhelper.app（Qt，随包提供、已 Developer ID 签名）负责屏幕捕获 UI 与
PixPin 滚动拼接。支持区域/窗口/滚动长截图、主题与图标定制。

权威接口文档：`include/screentool.h`（含事件回调、错误码、trigger 语义全注释）。

## 文件清单

- `libscreentool.dylib` → `libscreentool.1.dylib` → `libscreentool.1.2.2.dylib`（客户端库，零非系统依赖）
- `helper/screenhelper.app` —— **截图 helper 独立进程**（内含 Qt 运行时与
  PixPin 滚动拼接库），已用 Developer ID（TeamID F3TYM6YPF7）签名；
  rpath 已相对化（`@executable_path/../Frameworks`），**目标机无需安装 Qt，
  整目录拷贝即可用**

## 权限（必须）

- helper 需要「屏幕录制」+「辅助功能」（首次触发截图时系统弹窗，引导用户到
  系统设置授权）。
- **签名红线**：TCC 授权按证书匹配。screenhelper.app 保持随包签名原样分发；
  宿主切勿对它 ad-hoc 重签（会使已授予的屏幕录制/辅助功能失效，用户被迫反复
  重新授权）。宿主自身与其它库不受此限。

## 典型集成流程（C ABI）

```c
#include "screentool.h"

sct_handle h = sct_create();
sct_set_event_callback(h, on_event, NULL);      // 截图完成/取消/失败（路径回传）
sct_set_log_callback(h, on_log, NULL);
// 关键：指定 helper 可执行文件绝对路径（本包内 helper/screenhelper.app）
sct_set_helper_path(h, "/path/to/screentool/helper/screenhelper.app"
                       "/Contents/MacOS/screenhelper");
sct_connect_async(h, 5000);                     // 首次触发时懒拉起 helper 进程
// 截图会话：
sct_start_capture(h, trigger);                  // trigger 语义见头文件
sct_cancel_capture(h);                          // Esc/宿主取消
sct_query_state(h);                             // helper 状态（含权限实测回读）
sct_shutdown(h, pins_policy);                   // 收尾（可回收 helper 进程）
sct_destroy_wait(h);                            // FFI 宿主推荐：阻塞回收全部内部线程
sct_destroy(h);                                 // 旧非阻塞语义保留兼容
```

## 1.2.2 功能要点（相对 1.2.1）

- **`sct_destroy_wait` 销毁屏障**（新增）：置 stopping、清回调入口、唤醒/
  取消阻塞 IO 后先回收 connector 再回收 reader；FFI 宿主（Python/Node 等）
  在 worker 调用它，返回后方可注销回调或卸载动态库。旧 `sct_destroy`
  detach 语义保留。
- **Word 下载上限对齐 JS 路径**：Content-Length 头预检 + 累计 50MiB +
  64KiB 接收缓冲，超限/错误/空/成功四类明确结果。
- **mac 滚动截图防误触桌面**（本轮重点）：进入长截图不再撤销截图蒙层——
  蒙层只挖选区矩形一个洞透出活页面，PixPin 工具条/预览/选区框整体置顶于
  蒙层之上；选区外任何点击（含窗间缝隙）都落在蒙层上被拦截，不再触发
  "点按墙纸显示桌面"把会话收走。系统级打断（F11/Cmd+H）回前台后自动
  恢复会话现场（重扫透明化 + 举窗 + re-show 活窗）。
- **截图溜边修复**：框选整框拖动撞屏幕边时尺寸不再丢失（贴边钳位）；
  多屏跟屏重锚（光标换屏自动重跑锚定，修"副屏截图用了主屏参数"）。
- **滚动透明化恢复**：mac 滚动会话的窗口透明化退出时恢复原透明度
  （QPointer 记录，取消/结束/析构三出口齐备，不再残留透明窗）。
- **滚动窗层级残留修复**：置顶的工具条/预览在会话结束统一降回原生层级
  ——长截图结束后再次发起截图不再被上一次的会话窗遮挡（本机实测零残留）。
- **重新截图叠影修复**：已有选区时重新触发截图，抓屏前等待窗口合成器
  移除旧帧——新画面不再含旧选区/工具栏。
- **保存面板可见修复**：LSUIElement 后台应用的 NSSavePanel 原本不前置
  显示（用户"看不到保存框只能按 Esc"）——弹框期间临时切 Regular 策略，
  面板正常前置；取消恢复截图会话，保存 PNG 完整可打开。
- **OCR 结果窗找回**：结果窗被其他应用盖住或最小化后，经 Dock 图标
  （窗口存在期间自动出现）/『显示所有窗口』可激活找回，原识别文字仍在。
- 管道名 `sct_pipe_name()`（用户级唯一），多宿主进程安全。
- `sct_query_state` 回读 helper 实测权限与 bundle 路径（宿主可据此引导授权）。
- 主题/应用图标定制：`sct_set_theme` / `sct_list_themes` / `sct_set_app_icon`。
- `sct_kill_stale_helper`：Windows 按映像路径枚举清理残留；macOS 平台无
  等价安全机制，文档化返回 `SCT_ERR_REFUSED`。
- IPC 帧防御：声明长度超上限显式拒绝（客户端/网关/宿主三侧一致）。

## 线程约定

事件回调来自 IPC 线程，勿阻塞；会话控制 API 线程安全。
