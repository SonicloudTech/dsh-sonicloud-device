/**
 * ============================================================================
 * screentool —— 截图工具宿主客户端库 对外接口（C ABI）
 * ============================================================================
 *
 * 产品形态 : 单一动态库（Windows: screentool.dll / Linux: libscreentool.so /
 *            macOS: libscreentool.dylib），无 Qt 等第三方运行期依赖。
 * 与 helpers 的关系 : 本库只是宿主侧客户端——全部截图功能（选区/标注/贴图/
 *            滚动截图 UI）都在独立进程 screenhelper.exe 中完成，本库负责：
 *            拉起/连接 helper 进程、封装 IPC 帧协议、把 helper 事件透传给宿主。
 *            helper 与本库版本配套发布（helper 运行期自带的 Qt5 运行库在
 *            宿主的依赖目录中，与本库无关）。
 * 支持平台 : Windows 7+ / Linux / macOS（与 uMouseSdk/AsrTools/typer 同矩阵）
 * 适用宿主 : C / C++ / Qt(直接包含本头) / Electron(koffi 等 FFI) /
 *            Python(ctypes) / C#(P/Invoke) 等一切可调用 C ABI 的语言。
 *
 * ----------------------------------------------------------------------------
 * 典型调用序列（鼠标截图键 → 截图）
 * ----------------------------------------------------------------------------
 *   1. sct_create()                                    创建句柄
 *   2. sct_set_event_callback(h, on_event, user)       事件回调（必需）
 *   3. sct_set_helper_path(h, "…/screenhelper.exe")    helper 路径（可选）
 *   4. 鼠标截图键:  sct_start_capture(h, "mouse")      触发截图
 *      - 首次触发会自动拉起 helper 并连接（结果经 connected/connect_failed
 *        事件上报；连接成功后自动补发挂起的 start_capture）；
 *      - 截图进行中再次触发返回 SCT_ERR_BUSY（宿主据此忽略重复按键）。
 *   5. 用户确认/取消 → session_started / capture_confirmed(载荷=PNG) /
 *      session_ended 等事件依次回调；贴图经 pin_opened/pin_closed 上报。
 *   6. 宿主退出前:  sct_shutdown(h, "close_now")       关闭 helper（含贴图）
 *      之后 sct_destroy(h) 销毁句柄。
 *
 * ----------------------------------------------------------------------------
 * 线程契约（重要；2026-08-18 修订，详见 docs/宿主客户端死锁修复-2026-08-18.md）
 * ----------------------------------------------------------------------------
 *   - 本库线程安全：sct_* 可从任意线程调用；建议由同一调用方串行发起。
 *   - 事件/日志回调在库内部线程（IPC 读取线程 / 连接线程）触发；唯一例外：
 *     已连接状态下调用 sct_connect_async 会立即在调用线程内同步补发一次
 *     connected 事件（方便幂等使用）。
 *   - 部分宿主运行时（Electron/koffi 等 FFI）对跨线程回调的投递方式是
 *     “库线程阻塞等待宿主线程执行完回调”。因此本库保证：
 *       1) 任何 API 调用都不会等待库线程完成一次回调投递；
 *       2) 任何管道写都在 1.5s 上限内返回（helper 假死也绝不无限阻塞调用
 *          线程——2026-08-18 真机事故：sct_shutdown 曾挂起 2 分 37 秒）；
 *       3) sct_destroy 立即返回（见下）；
 *       4) 回调内可以调用本库任意非销毁接口（只读接口如 sct_is_connected
 *          为原子读，不会与回调投递互锁）。
 *   - 请勿在任何回调内阻塞或调用 sct_destroy / sct_set_*_callback。
 *   - 回调收到的指针（event_json/payload/message）仅在回调返回前有效，
 *     需要保留请自行拷贝。
 *   - sct_destroy 立即返回、绝不等待线程：内部先摘除全部回调（此后库线程
 *     不再进入宿主），再打断阻塞 IO 并 detach 全部线程。可能在途的最后一次
 *     回调投递由宿主事件循环稍后消化；库内部状态由 shared_ptr 保活至全部
 *     线程退出后自动释放。传入 NULL 安全。
 *
 * ----------------------------------------------------------------------------
 * helper 假死自愈（2026-08-18 晚新增；1.1.0 扩展外部残留实例）
 * ----------------------------------------------------------------------------
 *   - 库内置三层看门狗：hello_ack 3s / start_capture 后 session_started 3s /
 *     会话进行中静默 5s（helper 每秒心跳，彻底无帧=中途假死）。
 *     超时判定 helper 假死（进程活着但不读不回），自动：断连上报
 *     （disconnected，reason="helper unresponsive (…)"）→ 强杀假死实例
 *     → 重连重拉（触发在途则连接成功后自动补发 start_capture）。
 *   - 杀进程范围：本库拉起的实例按进程句柄杀（无 PID 复用误杀）；
 *     非本库拉起的残留实例（如上次宿主异常退出遗留）自 1.1.0 起同样
 *     自愈——双守卫：目标进程映像路径与 sct_set_helper_path 所设路径一致
 *     才杀（防误杀无关进程）；映像不符则上报
 *     {"type":"connect_failed","code":"stale_helper_refused","pid":N}
 *     并停止本次尝试，由宿主提示用户。连接循环同样识别"管道被接受但
 *     hello 写超时"的残留占用（连续 2 次即清理，之后自动重拉）。
 *   - 连续自愈最多 2 次（收到 session_ended 即复位计数）；超过后上报
 *     {"type":"connect_failed","code":"watchdog_exhausted", …}
 *     并停止自动重试，宿主下次 sct_start_capture 重新发起。
 *   - 宿主无需额外处理，但应预期可能收到上述 disconnected/connect_failed
 *     事件（现有事件处理已覆盖）。
 *
 * ----------------------------------------------------------------------------
 * 文本编码与多语言（重要）
 * ----------------------------------------------------------------------------
 *   - 所有 const char* 参数与返回值（helper 路径、事件 JSON、日志、管道名）
 *     一律 UTF-8；
 *   - 管道名中的用户名取自环境变量 USERNAME（回退 USER，再回退 "common"）：
 *     Windows 上按 ANSI 代码页解码（与 helper 侧 Qt 的 local8bit 语义一致，
 *     支持中文等非 ASCII 用户名），POSIX 上即原生 UTF-8。
 *
 * ----------------------------------------------------------------------------
 * IPC 协议（与 docs/实施计划.md 帧协议 v1.1 一致，无需宿主关心）
 * ----------------------------------------------------------------------------
 *   [4B total_len(小端)][2B header_len(小端)][JSON header][binary payload]
 *   管道名按用户隔离：clawmouse_screenhelper_v1_<USERNAME|USER|common>
 *   （Windows 命名管道 / Linux/macOS 本地 unix domain socket）。
 * ============================================================================
 */
#ifndef SCREENTOOL_H
#define SCREENTOOL_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* 导出宏 */
#if defined(_WIN32)
    #if defined(SCREENTOOL_STATIC)
        #define SCT_API
    #elif defined(SCREENTOOL_EXPORTS)
        #define SCT_API __declspec(dllexport)
    #else
        #define SCT_API __declspec(dllimport)
    #endif
#else
    #define SCT_API __attribute__((visibility("default")))
#endif

#define SCT_VERSION_STRING "1.2.2"

/* --------------------------------------------------------------------------
 * 错误码（sct_* 返回值）
 * ------------------------------------------------------------------------ */
#define SCT_OK                 0    /* 成功 / 已受理（异步结果经事件上报） */
#define SCT_ERR_INVALID_PARAM (-1) /* 参数为空 / 非法 */
#define SCT_ERR_NOT_CONNECTED  (-2) /* 尚未连接 helper（且未设 helper 路径，无法自动拉起） */
#define SCT_ERR_BUSY           (-3) /* 截图会话进行中（宿主应忽略本次触发） */
#define SCT_ERR_IO             (-4) /* 管道读写失败（连接会经 disconnected 事件复位） */
#define SCT_ERR_INTERNAL       (-5) /* 库内部错误（不应出现，出现请反馈） */
#define SCT_ERR_REFUSED        (-6) /* 拒绝执行（安全守卫：如目标进程映像与 helper 路径不符，防误杀） */

/* 日志级别（sct_set_log_callback 回调的 level 参数） */
#define SCT_LOG_DEBUG 0
#define SCT_LOG_INFO  1
#define SCT_LOG_WARN  2
#define SCT_LOG_ERROR 3

typedef struct sct_context* sct_handle;

/* --------------------------------------------------------------------------
 * 回调
 * ------------------------------------------------------------------------ */

/* 事件回调。
 * - helper 事件原样透传：event_json 即 helper 帧头 JSON（utf-8，紧凑格式），
 *   type 取值：hello_ack / session_started / capture_confirmed / ocr_requested /
 *   session_ended / pin_opened / pin_closed / state_report / error
 *   （helper 的 1s heartbeat 帧由本库吞掉，不透传）；
 *   session_ended 的 reason：copied / saved / pinned / canceled / escaped /
 *   exited / ocr；
 *   payload/payload_len 为帧二进制载荷（capture_confirmed/ocr_requested 的
 *   PNG 图像），无载荷时 payload=NULL、payload_len=0。
 * - 连接生命周期事件（本库合成）：
 *   {"type":"connected"}                        连接成功（已自动发送 hello）
 *   {"type":"disconnected","reason":"…"}        连接断开（helper 退出/被替换）
 *   {"type":"connect_failed","message":"…",     连接/拉起 helper 失败（超时等）。
 *    "code":"…","pid":N}                        code（1.1.0 起，可选）：
 *                                               connect_timeout=超时；watchdog_exhausted=
 *                                               看门狗自愈超过上限；stale_helper_refused=
 *                                               管道被残留进程占用但映像不符（拒绝杀，
 *                                               pid=占用者，宿主应提示用户处理） */
typedef void (*sct_on_event_fn)(void* user_data, const char* event_json,
                                const uint8_t* payload, int payload_len);

/* 日志回调（库内部线程触发；message 为 utf-8，仅回调期间有效）。 */
typedef void (*sct_on_log_fn)(void* user_data, int level, const char* message);

/* --------------------------------------------------------------------------
 * API
 * ------------------------------------------------------------------------ */

/* 库版本号字符串，如 "1.0.0"。 */
SCT_API const char* sct_version(void);

/* 错误码描述（utf-8 静态字符串）。 */
SCT_API const char* sct_strerror(int rc);

/* 当前用户实际使用的管道名（诊断用；utf-8 静态字符串，到进程内下次调用前有效）。
 * 例：clawmouse_screenhelper_v1 Administrator */
SCT_API const char* sct_pipe_name(void);

/* 创建句柄。返回 NULL 表示失败（内存不足）。 */
SCT_API sct_handle sct_create(void);

/* 销毁句柄：立即返回、绝不等待内部线程（先摘回调→打断阻塞 IO→detach 线程；
 * 可能在途的最后一次回调投递由宿主事件循环稍后消化）。不向 helper 发送
 * shutdown——宿主应先显式 sct_shutdown。传入 NULL 安全，可从任意线程调用。 */
SCT_API void sct_destroy(sct_handle h);

/* 停止并等待内部线程/在途回调全部结束，然后销毁句柄。
 * 不得从本句柄的回调内调用。FFI 宿主须在 worker 调用并保持事件循环运行；
 * 本调用返回后方可注销回调或卸载动态库。旧 sct_destroy 的非阻塞语义保留。 */
SCT_API void sct_destroy_wait(sct_handle h);

/* 设置/替换事件回调（fn=NULL 清空；回调参数见上）。应在 connect 前设置。 */
SCT_API int sct_set_event_callback(sct_handle h, sct_on_event_fn fn, void* user_data);

/* 设置/替换日志回调。 */
SCT_API int sct_set_log_callback(sct_handle h, sct_on_log_fn fn, void* user_data);

/* 设置 helper 可执行文件路径（utf-8）。
 * - 设置后：未连接时 sct_start_capture / sct_connect_async 会自动拉起 helper；
 * - 不设置（默认空）：只尝试连接已运行实例，连不上返回/上报失败。
 * 建议指向宿主依赖目录中的独立 helper 部署（exe + 其自带 Qt5 运行库）。 */
SCT_API int sct_set_helper_path(sct_handle h, const char* utf8_exe_path);

/* 异步连接（不阻塞调用线程）：
 * 先尝试连接既有 helper，失败则拉起 helper（需已设路径）并每 200ms 重试，
 * 至 timeout_ms 为止。结果经事件回调上报（connected / connect_failed）；
 * 连接成功后本库自动发送 hello（hello_ack 会作为事件透传）。
 * 已连接时调用：立即在调用线程同步补发一次 connected 事件并返回 SCT_OK。
 * 连接尝试进行中重复调用：静默忽略（返回 SCT_OK）。 */
SCT_API int sct_connect_async(sct_handle h, int timeout_ms);

/* 当前是否已连接 helper。 */
SCT_API int sct_is_connected(sct_handle h);

/* 截图会话是否进行中（session_started 起、session_ended/disconnect 止；
 * 发送 start_capture 时即置位，容忍事件延迟）。 */
SCT_API int sct_is_capturing(sct_handle h);

/* 触发一次截图（对应“鼠标截图键”）。
 * trigger : 触发来源标识（如 "mouse"/"ui"/"hotkey"，仅允许字母数字与 _-.，
 *           非法字符将被替换；NULL 视为 "ui"）。
 * - 未连接但已设 helper 路径：自动发起连接（本次触发挂起，连接成功后
 *   自动补发），返回 SCT_OK；
 * - 未连接且未设路径：返回 SCT_ERR_NOT_CONNECTED；
 * - 截图进行中：返回 SCT_ERR_BUSY（helper 不被扰动，宿主应忽略重复触发）；
 * - 成功发起：返回 SCT_OK，后续经 session_started 等事件上报。 */
SCT_API int sct_start_capture(sct_handle h, const char* trigger);

/* 取消进行中的截图（无会话时无副作用，返回 SCT_OK）。 */
SCT_API int sct_cancel_capture(sct_handle h);

/* 查询 helper 状态（pins_alive/capturing/helper_ver，经 state_report 事件返回）。 */
SCT_API int sct_query_state(sct_handle h);

/* [M4] 主题热切：theme_name = "electron" | "electron-dark"（未知名 helper 侧
 * 回退 electron 并告警）。立即生效于已开窗口。 */
SCT_API int sct_set_theme(sct_handle h, const char* theme_name);

/* [M4] helper 进程窗口/任务栏图标：utf8_icon_path 支持 png/ico；Windows 下也接受
 * .exe/.dll 路径（抽内嵌图标——传宿主自身 exe 路径即复用主进程图标）。
 * 传空串恢复 helper 默认图标。 */
SCT_API int sct_set_app_icon(sct_handle h, const char* utf8_icon_path);

/* [1.2.0] 运行期配置下发：config_json 为 JSON 对象字符串（字段=helper 端
 * HelperConfig 支持的键的子集，增量合并），如
 *   {"ocr_provider":"http","ocr_token":"mouse_xxx"}
 * 典型用途：宿主持有动态 token（passport 服务按设备签发），截图/识别前
 * 下发给 helper 供 OCR 使用——替代编译期静态 token。
 * 需已连接；未连接返回 SCT_ERR_NOT_CONNECTED（宿主应在 connected 事件后
 * 补发）。config_json 必须是合法 JSON 对象；"type" 键为保留字，调用方
 * 不得携带（会被 helper 忽略/错乱）。 */
SCT_API int sct_set_config(sct_handle h, const char* utf8_json);

/* [M4] 查询可用主题（经 theme_list 事件返回：themes 数组 + current）。 */
SCT_API int sct_list_themes(sct_handle h);

/* [G1] 手动清理残留假死 helper（恢复用途 API）。按映像路径枚举系统进程，
 * 只杀与 sct_set_helper_path 所设路径一致、且非本库拉起的实例——防误杀
 * 双守卫。正常路径无需调用（连接循环对残留占用自动清理，见上"假死自愈"）；
 * 仅在连接持续失败后作为兜底调用，正常状态下调用可能杀掉正在服务其他
 * 宿主的健康实例。
 * 返回 SCT_OK=已处理（杀掉 N 个或无可清理）；SCT_ERR_INVALID_PARAM=未设
 * helper 路径；SCT_ERR_REFUSED=平台暂不支持（macOS）。 */
SCT_API int sct_kill_stale_helper(sct_handle h);

/* 请求 helper 退出：
 * pins_policy = "close_now"（默认，连同贴图一起关闭）| "keep_detached"
 * （helper 游离保贴图存活，宿主重启后可重连复用）。
 * 发出后 helper 关闭管道，宿主将收到 disconnected 事件。 */
SCT_API int sct_shutdown(sct_handle h, const char* pins_policy);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* SCREENTOOL_H */
